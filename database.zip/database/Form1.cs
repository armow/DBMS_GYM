﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace database
{
    public partial class Form1 : Form
    {
        static string dbHost = "127.0.0.1";
        static string dbUser = "root";
        static string dbPass = "XROK83070";
        static string dbName = "gym";
        string SQL="";
        MySqlDataAdapter adapter;
        DataTable dt;
        string method="";
        string table = "", table1 = "";
        string word = ""; 
        string cond = "", cond1 = "";
        string change = "";
        string choose = "", choose1 = "";
        string have = "";
        string nest = "";
        string vin = "";
        string iiii = "";
        string MNUMBER = "", MNAME = "", PHONE = "", AGE = "", TNO = "", PNAM = "";
        string TNUMBER = "", TNAME = "", EXPERIENCE = "", WORKHOUR = "";
        string PNAME = "", DEADLINE = "", PRICE = "", MEMBERSHIP = "";
        string BNAME = "", AREA = "", OPENHOUR = "";
        string CNUMBER = "", CNAME = "", PEOPLELIMIT = "", TNUM = "";

        private void result_Click(object sender, EventArgs e)
        {

        }

        string MNO = "", CNO = "";

        private void text_TextChanged(object sender, EventArgs e)
        {

        }

        string MNUM = "", PNA = "";
        string BNAM = "", CNUM = "";
        string BNA = "";
        int i = 0, j = 0, k = 0, m = 0;
        int n = 0, p = 0, q = 0;
        int a = 0, b = 0, c = 0, d = 0;
        int iii = 0;

        static string connStr = "server=" + dbHost + ";uid=" + dbUser + ";pwd=" + dbPass + ";database=" + dbName;
        MySqlConnection conn = new MySqlConnection(connStr);


        public Form1()
        {
            InitializeComponent();         
        }

        private void init()          //初始化
        {
            method = "";
            table = "";table1 = "";
            word = "";
            cond = "";cond1 = "";
            change = "";
            choose = "";choose1 = "";
            have = "";
            nest = "";
            vin = "";
            iiii = "";
            MNUMBER = ""; MNAME = ""; PHONE = ""; AGE = ""; TNO = ""; PNAM = "";
            TNUMBER = ""; TNAME = ""; EXPERIENCE = ""; WORKHOUR = "";
            PNAME = ""; DEADLINE = ""; PRICE = ""; MEMBERSHIP = "";
            BNAME = ""; AREA = ""; OPENHOUR = "";
            CNUMBER = ""; CNAME = ""; PEOPLELIMIT = ""; TNUM = "";
            MNO = ""; CNO = "";
            MNUM = ""; PNA = "";
            BNAM = ""; CNUM = "";
            BNA = "";
            i = 0; j = 0; k = 0; m = 0;
            n = 0; p = 0; q = 0;
            a = 0; b = 0;c = 0;d = 0;
            iii = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {          
            if (comboBox1.SelectedValue.ToString() == "insert")     //新增資料
            {               
                if (table == "member")
                    word = "insert into " + table + " values (" + "'" + MNUMBER + "'" + "," + "'" + MNAME + "'" + "," + "'" + PHONE + "'" + "," + "'" + AGE + "'" + "," + "'" + TNO + "'" + "," + "'" + PNAM + "'" + ")";
                else if (table == "trainer")
                    word = "insert into " + table + " values (" + "'" + TNUMBER + "'" + "," + "'" + TNAME + "'" + "," + "'" + EXPERIENCE + "'" + "," + "'" + WORKHOUR + "'" + ")";
                else if (table == "proposal")
                    word = "insert into " + table + " values (" + "'" + PNAME + "'" + "," + "'" + DEADLINE + "'" + "," + "'" + PRICE + "'" + "," + "'" + MEMBERSHIP + "'" + ")";
                else if (table == "branch")
                    word = "insert into " + table + " values (" + "'" + BNAME + "'" + "," + "'" + AREA + "'" + "," + "'" + OPENHOUR + "'" + ")";
                else if (table == "course")
                    word = "insert into " + table + " values (" + "'" + CNUMBER + "'" + "," + "'" + CNAME + "'" + "," + "'" + PEOPLELIMIT + "'" + "," + "'" + TNUM + "'" + ")";
                else if (table == "apply")
                    word = "insert into " + table + " values (" + "'" + MNO + "'" + "," + "'" + CNO + "'" + ")";
                else if (table == "inquire")
                    word = "insert into " + table + " values (" + "'" + MNUM + "'" + "," + "'" + PNA + "'" + ")";
                else if (table == "have")
                    word = "insert into " + table + " values (" + "'" + BNAM + "'" + "," + "'" + CNUM + "'" + ")";
                else if (table == "belong")
                    word = "insert into " + table + " values (" + "'" + MNO + "'" + "," + "'" + TNO + "'" + "," + "'" + BNA + "'" + ")";
                SQL = word;
            }
            else if (comboBox1.SelectedValue.ToString() == "delete")    //刪除資料
            {
                word = "delete from " + table + " where "+cond;
                SQL = word;
            }
            else if (comboBox1.SelectedValue.ToString() == "update")    //更新資料
            {
                word = "update " + table + " set "+change+" where "+cond;
                SQL = word;
            }
            else if (comboBox1.SelectedValue.ToString() == "select")    //搜尋資料
            {
                if (a == 1 && b == 0 && c == 0 && d == 0)
                    word = "select " + choose + " from " + table + " where " + cond;
                else if (a == 1 && b == 1)
                    word = "select " + choose + " from " + table + " where " + cond + " " + have;
                else if (a == 0 && b == 0)
                    word = "select " + choose + " from " + table;
                else if (a == 0 && b == 1)
                    word = "select " + choose + " from " + table + " " + have;
                else if (a == 1 && b == 0 && c == 1 && d == 0)
                    word = "select " + choose + " from " + table + " where " + nest + "(select " + choose1 + " from " + table1 + " where " + cond1 + ")";
                else if (a == 1 && b == 0 && c == 0 && d == 1 && iii != 2)
                    word = "select " + choose + " from " + table + " where " + vin + " " + nest + "(select " + choose1 + " from " + table1 + " where " + cond1 + ")";
                else if (a == 1 && b == 0 && c == 0 && d == 1 && iii == 2)
                    word = "select " + choose + " from " + table + " where " + vin + " " + nest + "(" + iiii + ")";
                SQL = word;
            }
            else if (comboBox1.SelectedValue.ToString() == "SQL")   //直接輸入指令
                SQL = text.Text;

            if (SQL.Substring(0, 1) == "s" || SQL.Substring(0, 1) == "S")   //搜尋資料
            {
                result.Text = SQL;
                search();
            }
            else    //新增刪除更新資料
            {
                result.Text = SQL;
                another();
            }
            init();
        }

        public class cboDataList
        {
            public string cbo_Name { get; set; }
            public string cbo_Value { get; set; }
            public string cbo_Name1 { get; set; }
            public string cbo_Value1 { get; set; }
            public string cbo_Name2 { get; set; }
            public string cbo_Value2 { get; set; }
            public string cbo_Name3 { get; set; }
            public string cbo_Value3 { get; set; }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            //連線到資料庫
            try
            {
                conn.Open();
                //result.Text="Connected Success!";
            }
            catch (MySql.Data.MySqlClient.MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        result.Text = "無法連線到資料庫.";
                        break;
                    case 1042:
                        result.Text = "IP 錯誤.";
                        break;
                    case 1045:
                        result.Text = "使用者帳號或密碼錯誤.";
                        break;
                }
            }

            //選單的呈現
            List<cboDataList> lis_DataList = new List<cboDataList>()
            {
                new cboDataList
                {
                    cbo_Name = "SQL",
                    cbo_Value = "SQL"
                },
                new cboDataList
                {
                    cbo_Name = "搜尋資料",
                    cbo_Value = "select"
                },
                new cboDataList
                {
                    cbo_Name = "新增資料",
                    cbo_Value = "insert"
                },
                new cboDataList
                {
                    cbo_Name = "刪除資料",
                    cbo_Value = "delete"
                },
                new cboDataList
                {
                    cbo_Name = "更新資料",
                    cbo_Value = "update"
                }
            };

            List<cboDataList> lis_DataList1 = new List<cboDataList>()
            {              
                new cboDataList
                {
                    cbo_Name1 = "member",
                    cbo_Value1 = "member"
                },
                new cboDataList
                {
                    cbo_Name1 = "trainer",
                    cbo_Value1 = "trainer"
                },
                new cboDataList
                {
                    cbo_Name1 = "proposal",
                    cbo_Value1 = "proposal"
                },
                new cboDataList
                {
                    cbo_Name1 = "branch",
                    cbo_Value1 = "branch"
                },
                new cboDataList
                {
                    cbo_Name1 = "course",
                    cbo_Value1 = "course"
                },
                new cboDataList
                {
                    cbo_Name1 = "apply",
                    cbo_Value1 = "apply"
                },
                new cboDataList
                {
                    cbo_Name1 = "inquire",
                    cbo_Value1 = "inquire"
                },
                new cboDataList
                {
                    cbo_Name1 = "have",
                    cbo_Value1 = "have"
                },
                new cboDataList
                {
                    cbo_Name1 = "belong",
                    cbo_Value1 = "belong"
                }
            };

            List<cboDataList> lis_DataList2 = new List<cboDataList>()
            {
                new cboDataList
                {
                    cbo_Name2 = "*",
                    cbo_Value2 = "*"
                },
                new cboDataList
                {
                    cbo_Name2 = "MNUMBER",
                    cbo_Value2 = "MNUMBER"
                },
                new cboDataList
                {
                    cbo_Name2 = "MNAME",
                    cbo_Value2 = "MNAME"
                },
                new cboDataList
                {
                    cbo_Name2 = "PHONE",
                    cbo_Value2 = "PHONE"
                },
                new cboDataList
                {
                    cbo_Name2 = "AGE",
                    cbo_Value2 = "AGE"
                },
                new cboDataList
                {
                    cbo_Name2 = "TNO",
                    cbo_Value2 = "TNO"
                },
                new cboDataList
                {
                    cbo_Name2 = "PNAM",
                    cbo_Value2 = "PNAM"
                },
                new cboDataList
                {
                    cbo_Name2 = "TNUMBER",
                    cbo_Value2 = "TNUMBER"
                },
                new cboDataList
                {
                    cbo_Name2 = "TNAME",
                    cbo_Value2 = "TNAME"
                },
                new cboDataList
                {
                    cbo_Name2 = "EXPPERIENCE",
                    cbo_Value2 = "EXPERIENCE"
                },
                new cboDataList
                {
                    cbo_Name2 = "WORKHOUR",
                    cbo_Value2 = "WORKHOUR"
                },
                new cboDataList
                {
                    cbo_Name2 = "PNAME",
                    cbo_Value2 = "PNAME"
                },
                new cboDataList
                {
                    cbo_Name2 = "DEADLINE",
                    cbo_Value2 = "DEADLINE"
                },
                new cboDataList
                {
                    cbo_Name2 = "PRICE",
                    cbo_Value2 = "PRICE"
                },
                new cboDataList
                {
                    cbo_Name2 = "MEMBERSHIP",
                    cbo_Value2 = "MEMBERSHIP"
                },
                new cboDataList
                {
                    cbo_Name2 = "BNAME",
                    cbo_Value2 = "BNAME"
                },
                new cboDataList
                {
                    cbo_Name2 = "AREA",
                    cbo_Value2 = "AREA"
                },
                new cboDataList
                {
                    cbo_Name2 = "OPENHOUR",
                    cbo_Value2 = "OPENHOUR"
                },
                new cboDataList
                {
                    cbo_Name2 = "CNUMBER",
                    cbo_Value2 = "CNUMBER"
                },
                new cboDataList
                {
                    cbo_Name2 = "CNAME",
                    cbo_Value2 = "CNAME"
                },
                new cboDataList
                {
                    cbo_Name2 = "PEOPLELIMIT",
                    cbo_Value2 = "PEOPLELIMIT"
                },
                new cboDataList
                {
                    cbo_Name2 = "TNUM",
                    cbo_Value2 = "TNUM"
                },
                new cboDataList
                {
                    cbo_Name2 = "MNO",
                    cbo_Value2 = "MNO"
                },
                new cboDataList
                {
                    cbo_Name2 = "CNO",
                    cbo_Value2 = "CNO"
                },
                new cboDataList
                {
                    cbo_Name2 = "MNUM",
                    cbo_Value2 = "MNUM"
                },
                new cboDataList
                {
                    cbo_Name2 = "PNA",
                    cbo_Value2 = "PNA"
                },
                new cboDataList
                {
                    cbo_Name2 = "BNAM",
                    cbo_Value2 = "BNAM"
                },
                new cboDataList
                {
                    cbo_Name2 = "CNUM",
                    cbo_Value2 = "CNUM"
                },
                new cboDataList
                {
                    cbo_Name2 = "MNO",
                    cbo_Value2 = "MNO"
                },
                new cboDataList
                {
                    cbo_Name2 = "TNO",
                    cbo_Value2 = "TNO"
                },
                new cboDataList
                {
                    cbo_Name2 = "BNA",
                    cbo_Value2 = "BNA"
                },
                new cboDataList
                {
                    cbo_Name2 = "COUNT",
                    cbo_Value2 = "COUNT"
                },
                new cboDataList
                {
                    cbo_Name2 = "SUM",
                    cbo_Value2 = "SUM"
                },
                new cboDataList
                {
                    cbo_Name2 = "MIN",
                    cbo_Value2 = "MIN"
                },
                new cboDataList
                {
                    cbo_Name2 = "MAX",
                    cbo_Value2 = "MAX"
                },
                new cboDataList
                {
                    cbo_Name2 = "AVG",
                    cbo_Value2 = "AVG"
                },
            };

            List<cboDataList> lis_DataList3 = new List<cboDataList>()
            {
                new cboDataList
                {
                    cbo_Name3 = "MNUMBER",
                    cbo_Value3 = "MNUMBER"
                },
                new cboDataList
                {
                    cbo_Name3 = "MNAME",
                    cbo_Value3 = "MNAME"
                },
                new cboDataList
                {
                    cbo_Name3 = "PHONE",
                    cbo_Value3 = "PHONE"
                },
                new cboDataList
                {
                    cbo_Name3 = "AGE",
                    cbo_Value3 = "AGE"
                },
                new cboDataList
                {
                    cbo_Name3 = "TNO",
                    cbo_Value3 = "TNO"
                },
                new cboDataList
                {
                    cbo_Name3 = "PNAM",
                    cbo_Value3 = "PNAM"
                },
                new cboDataList
                {
                    cbo_Name3 = "TNUMBER",
                    cbo_Value3 = "TNUMBER"
                },
                new cboDataList
                {
                    cbo_Name3 = "TNAME",
                    cbo_Value3 = "TNAME"
                },
                new cboDataList
                {
                    cbo_Name3 = "EXPPERIENCE",
                    cbo_Value3 = "EXPERIENCE"
                },
                new cboDataList
                {
                    cbo_Name3 = "WORKHOUR",
                    cbo_Value3 = "WORKHOUR"
                },
                new cboDataList
                {
                    cbo_Name3 = "PNAME",
                    cbo_Value3 = "PNAME"
                },
                new cboDataList
                {
                    cbo_Name3 = "DEADLINE",
                    cbo_Value3 = "DEADLINE"
                },
                new cboDataList
                {
                    cbo_Name3 = "PRICE",
                    cbo_Value3 = "PRICE"
                },
                new cboDataList
                {
                    cbo_Name3 = "MEMBERSHIP",
                    cbo_Value3 = "MEMBERSHIP"
                },
                new cboDataList
                {
                    cbo_Name3 = "BNAME",
                    cbo_Value3 = "BNAME"
                },
                new cboDataList
                {
                    cbo_Name3 = "AREA",
                    cbo_Value3 = "AREA"
                },
                new cboDataList
                {
                    cbo_Name3 = "OPENHOUR",
                    cbo_Value3 = "OPENHOUR"
                },
                new cboDataList
                {
                    cbo_Name3 = "CNUMBER",
                    cbo_Value3 = "CNUMBER"
                },
                new cboDataList
                {
                    cbo_Name3 = "CNAME",
                    cbo_Value3 = "CNAME"
                },
                new cboDataList
                {
                    cbo_Name3 = "PEOPLELIMIT",
                    cbo_Value3 = "PEOPLELIMIT"
                },
                new cboDataList
                {
                    cbo_Name3 = "TNUM",
                    cbo_Value3 = "TNUM"
                },
                new cboDataList
                {
                    cbo_Name3 = "MNO",
                    cbo_Value3 = "MNO"
                },
                new cboDataList
                {
                    cbo_Name3 = "CNO",
                    cbo_Value3 = "CNO"
                },
                new cboDataList
                {
                    cbo_Name3 = "MNUM",
                    cbo_Value3 = "MNUM"
                },
                new cboDataList
                {
                    cbo_Name3 = "PNA",
                    cbo_Value3 = "PNA"
                },
                new cboDataList
                {
                    cbo_Name3 = "BNAM",
                    cbo_Value3 = "BNAM"
                },
                new cboDataList
                {
                    cbo_Name3 = "CNUM",
                    cbo_Value3 = "CNUM"
                },
                new cboDataList
                {
                    cbo_Name3 = "MNO",
                    cbo_Value3 = "MNO"
                },
                new cboDataList
                {
                    cbo_Name3 = "TNO",
                    cbo_Value3 = "TNO"
                },
                new cboDataList
                {
                    cbo_Name3 = "BNA",
                    cbo_Value3 = "BNA"
                },
                new cboDataList
                {
                    cbo_Name3 = "HAVING",
                    cbo_Value3 = "HAVING"
                },
                new cboDataList
                {
                    cbo_Name3 = "EXISTS",
                    cbo_Value3 = "EXISTS"
                },
                new cboDataList
                {
                    cbo_Name3 = "NOT EXISTS",
                    cbo_Value3 = "NOTEXISTS"
                },
                new cboDataList
                {
                    cbo_Name3 = "IN",
                    cbo_Value3 = "IN"
                },
                new cboDataList
                {
                    cbo_Name3 = "NOT IN",
                    cbo_Value3 = "NOIN"
                }
            };

            comboBox1.DataSource = lis_DataList;
            comboBox1.DisplayMember = "cbo_Name";
            comboBox1.ValueMember = "cbo_Value";
            comboBox2.DataSource = lis_DataList1;
            comboBox2.DisplayMember = "cbo_Name1";
            comboBox2.ValueMember = "cbo_Value1";
            comboBox3.DataSource = lis_DataList2;
            comboBox3.DisplayMember = "cbo_Name2";
            comboBox3.ValueMember = "cbo_Value2";
            comboBox4.DataSource = lis_DataList3;
            comboBox4.DisplayMember = "cbo_Name3";
            comboBox4.ValueMember = "cbo_Value3";



        }

        private void search()   //連接到資料庫，用MySQL搜尋資料
        {
            adapter = new MySqlDataAdapter(SQL, conn);
            dt = new DataTable("data");
            adapter.Fill(dt);
            dgvDatabaseShow.DataSource = dt;
            dgvDatabaseShow.FirstDisplayedScrollingRowIndex = dgvDatabaseShow.Rows.Count - 1;         
        }

        private void another()  //連接到資料庫，用MySQL新增刪除更新資料
        {
            MySqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = SQL;
            cmd.ExecuteNonQuery();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)     //介面
        {
            if (comboBox1.SelectedValue.ToString() == "SQL")
            {
                comboBox2.Visible = false;
                label1.Visible = false;
                label2.Visible = false;
                label3.Visible = false;
                textBox1.Visible = false;
                textBox2.Visible = false;
                comboBox3.Visible = false;
                button2.Visible = false;
                button3.Visible = false;
                button4.Visible = false;
                comboBox4.Visible = false;
                text.Visible = true;
            }
            else if(comboBox1.SelectedValue.ToString() == "select")
            {
                method = "select";
                comboBox2.Visible = true;
                label1.Visible = true;
                label2.Visible = true;
                label3.Visible = true;
                textBox1.Visible = true;
                textBox2.Visible = true;
                comboBox3.Visible = true;
                button2.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                comboBox4.Visible = true;
                text.Visible = false;

            }
            else if (comboBox1.SelectedValue.ToString() == "insert")
            {
                method = "insert";
                comboBox2.Visible = true;
                label1.Visible = true;
                label2.Visible = true;
                label3.Visible = true;
                textBox1.Visible = true;
                textBox2.Visible = true;
                comboBox3.Visible = true;
                button2.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                comboBox4.Visible = true;
                text.Visible = false;
            }
            else if (comboBox1.SelectedValue.ToString() == "delete")
            {
                method = "delete";
                comboBox2.Visible = true;
                label1.Visible = true;
                label2.Visible = true;
                label3.Visible = true;
                textBox1.Visible = true;
                textBox2.Visible = true;
                comboBox3.Visible = true;
                button2.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                comboBox4.Visible = true;
                text.Visible = false;
            }
            else if (comboBox1.SelectedValue.ToString() == "update")
            {
                method = "update";
                comboBox2.Visible = true;
                label1.Visible = true;
                label2.Visible = true;
                label3.Visible = true;
                textBox1.Visible = true;
                textBox2.Visible = true;
                comboBox3.Visible = true;
                button2.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                comboBox4.Visible = true;
                text.Visible = false;

            }
        }

        private void button2_Click(object sender, EventArgs e)      //選擇table
        {
            string tmp;
            k++;
            tmp = comboBox2.SelectedValue.ToString();
            if (k == 1 && c ==0 && d == 0)  //選一次
                table = table + tmp;
            else if(k > 1 && c == 0 && d == 0)  //選兩次以上
                table = table + "," + tmp;
            else if (c == 1 || d == 1)  //Nested queries使用
            {
                n++;
                tmp = comboBox2.SelectedValue.ToString();
                if (n == 1)
                    table1 = table1 + tmp;
                else
                    table1 = table1 + "," + tmp;
            }
            
        }

        private void button3_Click(object sender, EventArgs e)  //資料區check
        {
            if (comboBox1.SelectedValue.ToString() == "insert")
            {
                if (comboBox3.SelectedValue.ToString() == "MNUMBER")
                    MNUMBER = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "MNAME")
                    MNAME = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "PHONE")
                    PHONE = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "AGE")
                    AGE = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "TNO")
                    TNO = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "PNAM")
                    PNAM = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "TNUMBER")
                    TNUMBER = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "TNAME")
                    TNAME = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "EXPERIENCE")
                    EXPERIENCE = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "WORKHOUR")
                    WORKHOUR = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "PNAME")
                    PNAME = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "DEADLINE")
                    DEADLINE = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "PRICE")
                    PRICE = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "MEMBERSHIP")
                    MEMBERSHIP = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "BNAME")
                    BNAME = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "AREA")
                    AREA = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "OPENHOUR")
                    OPENHOUR = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "CNUMBER")
                    CNUMBER = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "CNAME")
                    CNAME = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "PEOPLELIMIT")
                    PEOPLELIMIT = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "TNUM")
                    TNUM = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "MNO")
                    MNO = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "CNO")
                    CNO = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "MNUM")
                    MNUM = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "PNA")
                    PNA = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "BNAM")
                    BNAM = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "CNUM")
                    CNUM = textBox1.Text;
                else if (comboBox3.SelectedValue.ToString() == "BNA")
                    BNA = textBox1.Text;
            }
            else if (comboBox1.SelectedValue.ToString() == "update")
            {
                string tmp;
                j++;
                tmp = comboBox3.SelectedValue.ToString() + "=" + "'" + textBox1.Text + "'";
                if (j == 1)     //更新一項資料
                    change = change + tmp;
                else            //更新一項資料以上
                    change = change + " and " + tmp;
            }
            else if (comboBox1.SelectedValue.ToString() == "select")
            {
                string tmp;
                m++;
                if(comboBox3.SelectedValue.ToString()=="COUNT" || comboBox3.SelectedValue.ToString() == "SUM" || comboBox3.SelectedValue.ToString() == "MAX" || comboBox3.SelectedValue.ToString() == "MIN" || comboBox3.SelectedValue.ToString() == "AVG")
                {
                    tmp = comboBox3.SelectedValue.ToString() + "(" + textBox1.Text + ")";
                }
                else
                    tmp = comboBox3.SelectedValue.ToString();
                if (m == 1 && c == 0 && d == 0)     //搜尋一項資料
                    choose = choose + tmp;
                else if(m > 1 && c == 0 && d == 0)  //搜尋一項資料以上
                    choose = choose + "," + tmp;
                else if (c == 1 || d == 1)          //Nested queries使用
                {
                    p++;
                    tmp = comboBox3.SelectedValue.ToString();
                    if (p == 1)
                        choose1 = choose1 + tmp;
                    else
                        choose1 = choose1 + "," + tmp;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)      //條件區check
        {         
            //a:是否要印where   b:having    c:exists/not exists   d:in/not in
            if (comboBox1.SelectedValue.ToString() == "delete" || comboBox1.SelectedValue.ToString() == "update" || comboBox1.SelectedValue.ToString() == "select")
            {           
                if (comboBox4.SelectedValue.ToString() == "EXISTS" || comboBox4.SelectedValue.ToString() == "NOTEXISTS")
                {
                    a = 1;
                    nest = comboBox4.SelectedValue.ToString();
                    c = 1;                 
                }
                else if (comboBox4.SelectedValue.ToString() == "IN" || comboBox4.SelectedValue.ToString() == "NOTIN")
                {
                    a = 1;
                    iii++;
                    if (iii == 1)   //條件直接是資料
                    {
                        nest = comboBox4.SelectedValue.ToString();
                        d = 1;
                        vin = textBox2.Text;
                    }
                    else            //條件直接是select
                    {
                        iiii = textBox2.Text;
                    }
                }
                else if (comboBox4.SelectedValue.ToString() == "HAVING")
                {
                    b = 1;
                }
                else
                {
                    if (c == 1 || d == 1)    //Nested queries使用
                    {
                        string tmp;
                        q++;
                        if (q == 1)
                        {
                            tmp = comboBox4.SelectedValue.ToString() + "=" + textBox2.Text;
                            cond1 = cond1 + tmp;
                        }
                        else 
                        {
                            tmp = comboBox4.SelectedValue.ToString() + "=" + textBox2.Text;
                            cond1 = cond1 + " and " + tmp;
                        }
                    }
                    else if (b == 1)
                    {
                        have = "HAVING " + comboBox4.SelectedValue.ToString() + textBox2.Text;
                    }
                    else
                    {
                        a = 1;
                        if (comboBox3.SelectedValue.ToString() == "COUNT" || comboBox3.SelectedValue.ToString() == "SUM" || comboBox3.SelectedValue.ToString() == "MAX" || comboBox3.SelectedValue.ToString() == "MIN" || comboBox3.SelectedValue.ToString() == "AVG")
                        {
                            string tmp;
                            i++;
                            tmp = comboBox4.SelectedValue.ToString()  + textBox2.Text;
                            if (i == 1)             //選擇一項條件
                                cond = cond + tmp;
                            else                    //選擇一項條件以上
                                cond = cond + " and " + tmp;
                        }
                        else
                        {
                            string tmp;
                            i++;
                            tmp = comboBox4.SelectedValue.ToString() + "=" + textBox2.Text;
                            if (i == 1)
                                cond = cond + tmp;
                            else
                                cond = cond + " and " + tmp;
                        }
                    }
                    

                }         
                                                 
            }

            //if (comboBox1.SelectedValue.ToString() == "select")
            //a = 1;      
        }
    }
}             